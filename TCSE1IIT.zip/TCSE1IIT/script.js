document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const menuToggle = document.querySelector('.menu-toggle');
    const nav = document.querySelector('nav');
    
    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            nav.classList.toggle('active');
            menuToggle.classList.toggle('active');
        });
    }

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 70,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Animation for skill bars
    const skillBars = document.querySelectorAll('.skill-progress .progress');
    
    // Set initial width to 0 (will be animated via CSS)
    skillBars.forEach(bar => {
        // Get the width from inline style
        const width = bar.style.width;
        // Store the target width as a data attribute
        bar.setAttribute('data-width', width);
        // Set initial width to 0
        bar.style.width = '0';
    });

    // Animate elements when they come into view
    const animateOnScroll = () => {
        // Animate skill bars
        skillBars.forEach(bar => {
            const rect = bar.getBoundingClientRect();
            const isInView = rect.top <= window.innerHeight && rect.bottom >= 0;
            
            if (isInView) {
                // Set the width to the stored target width
                bar.style.width = bar.getAttribute('data-width');
            }
        });
        
        // Animate sections with fade-in class
        document.querySelectorAll('.fade-in').forEach(element => {
            const rect = element.getBoundingClientRect();
            const isInView = rect.top <= window.innerHeight && rect.bottom >= 0;
            
            if (isInView) {
                element.classList.add('visible');
            }
        });
    };

    // Run once on load
    setTimeout(animateOnScroll, 300);
    
    // Run on scroll
    window.addEventListener('scroll', animateOnScroll);
});